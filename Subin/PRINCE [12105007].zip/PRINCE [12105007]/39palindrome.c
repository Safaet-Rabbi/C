/******************************************************
 *    Author:  PRINCE_14                              *
 *          --MD. AN NAHIAN PRINCE                    *
 *          --CSE,BRUR                                *
 *          --ID: 12105007                            *
 *            PB: Palindrome [39]                     *
 ******************************************************/

#include<stdio.h>
#include<string.h>

int main()
{
    int t;
    scanf("%d",&t);
    getchar();
    while(t--)
    {
        char str1[10001], str2[10001];
        gets(str1);
        strcpy(str2,str1);
        strrev(str2);
        if(strcmp(str1,str2)==0)
        {
            printf("Yes! It is palindrome!\n");
        }
        else
        {
            printf("Sorry! It is not palindrome!\n");
        }   
    }

    return 0;
}