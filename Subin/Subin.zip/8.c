#include<stdio.h>
int main()
{
    int n,ara[4],i;
    scanf("%d",&n);
    while(n--){
        for(i = 0; i < 3; i++){
            scanf("%d",&ara[i]);
        }
        if(ara[0] > ara[1]){
            int temp = ara[0];
            ara[0] = ara[1];
            ara[1] = temp;
        }
        if(ara[1] > ara[2]){
            int temp = ara[1];
            ara[1] = ara[2];
            ara[2] = temp;
        }
        if(ara[0] > ara[1]){
            int temp = ara[0];
            ara[0] = ara[1];
            ara[1] = temp;
        }
        printf("Sorted array : ");
        for(i = 0; i < 3; i++){
            printf("%d ", ara[i]);
        }
        printf("\n");
    }
    return 0;
}
