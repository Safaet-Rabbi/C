#include <stdio.h>

#define MAX_N 10000

long long x[MAX_N + 1], y[MAX_N + 1], z[MAX_N + 1];

int main() {
    int T, n, m, i, j, k;
    long long ans, sum;

    scanf("%d", &T);

    for (int tc = 1; tc <= T; tc++) {
        scanf("%d%d", &n, &m);

        for (i = 1; i <= n; i++) {
            scanf("%lld%lld%lld", &x[i], &y[i], &z[i]);
        }

        ans = 0;

        for (i = 1; i <= m; i++) {
            sum = 0;
            scanf("%d%d%d", &j, &k, &m);

            for (int l = 1; l <= n; l++) {
                if (x[l] >= j && x[l] <= k && y[l] >= j && y[l] <= k && z[l] >= j && z[l] <= k) {
                    sum += m;
                }
            }

            ans += sum;
        }

        printf("Case %d: %lld\n", tc, ans);
    }

    return 0;
}
