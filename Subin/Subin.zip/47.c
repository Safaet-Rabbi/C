#include <stdio.h>
int main() {
    int t;
    scanf("%d", &t);
    while(t--){
        int n1, n2;
        scanf("%d", &n1);
        int arr1[n1];
        for (int i = 0; i < n1; i++) {
            scanf("%d", &arr1[i]);
        }
        scanf("%d", &n2);
        int arr2[n2];
        for (int i = 0; i < n2; i++) {
            scanf("%d", &arr2[i]);
        }

        int mergedArr[n1 + n2];
        int i = 0, j = 0, k = 0;
        while (i < n1 && j < n2) {
            if (arr1[i] <= arr2[j]) {
                mergedArr[k] = arr1[i];
                k++;
                i++;
            } else {
                mergedArr[k] = arr2[j];
                k++;
                j++;
            }
        }
        while (i < n1) {
            mergedArr[k] = arr1[i];
            k++;
            i++;
        }
        while (j < n2) {
            mergedArr[k] = arr2[j];
            k++;
            j++;
        }

        for (int i = 0; i <(n1 + n2); i++) {
            printf("%d ", mergedArr[i]);
        }
        printf("\n");
    }
    return 0;
}
