#include <stdio.h>
#include<math.h>
int main() {
    int n, count = 0, i,num;
    scanf("%d", &n);
    for (i = 5; i <= n; i=i+5) {
         num = i;
        while (num % 5 == 0) {
            count++;
            num = num / 5;
        }
    }

    printf("%d\n", count);
    return 0;
}
