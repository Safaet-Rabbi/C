#include <stdio.h>
int main() {
    int n;
    int prime = 1;
    scanf("%d",&n);
    if (n <= 1) {
        prime = 0;
    }
    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0) {
            prime = 0;
            break;
        }
    }
    if (prime>0) {
        printf("%d is a prime number\n", n);
    } else {
        printf("%d is not a prime number\n", n);
    }
    return 0;
}
