#include <stdio.h>
#include <string.h>
int main()
{
    int T, i, l;
    char str[100], str2[100];
    scanf("%d", &T);
    while(T--)
    {
        scanf("%s", &str);
        l = strlen(str);
        for(i = 0; i < l; i++)
        {
            if(str[i] == 'L' && i > 0)
            {
                str2[i] = str[i - 1];
            }
            else if(str[i] == 'R' && i < l - 1)
            {
                str2[i] = str[i + 1];
            }
            else
            {
                str2[i] = str[i];
            }
        }
        str2[l] = '\0'; // Add null terminator to the end of the string
        puts(str2);

    }
    return 0;
}
