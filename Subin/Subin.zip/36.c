#include<stdio.h>
#include<string.h>
int main()
{
    char str[20][20],temp[20];
    int n,i,j,k,t;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d",&n);
        for(i=1;i<=n;i++)
        {
            getchar();
            gets(str[i]);
        }
        for(i=1;i<=n-1;i++)
        {
            for(j=1;j<=n-1;j++)
            {
                if(str[j][0]>str[j+1][0])
                {
                    strcpy(temp,str[j]);
                    strcpy(str[j],str[j+1]);
                    strcpy(str[j+1],temp);
                }
            }
        }
        for(k=1;k<=n;k++)
        {
            puts(str[k]);
            printf("\n");
        }

    }
}
